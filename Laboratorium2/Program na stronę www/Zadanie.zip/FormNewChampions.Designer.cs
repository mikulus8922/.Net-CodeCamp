﻿
namespace MikołajRarokZad2
{
    partial class FormNewChampions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelChampionClass1 = new System.Windows.Forms.Label();
            this.labelChampionClass2 = new System.Windows.Forms.Label();
            this.labelChampionClass3 = new System.Windows.Forms.Label();
            this.labelHealthName1 = new System.Windows.Forms.Label();
            this.labelHealthName2 = new System.Windows.Forms.Label();
            this.labelHealthName3 = new System.Windows.Forms.Label();
            this.labelChampionHealth1 = new System.Windows.Forms.Label();
            this.labelChampionHealth2 = new System.Windows.Forms.Label();
            this.labelChampionHealth3 = new System.Windows.Forms.Label();
            this.labelChampionDefence3 = new System.Windows.Forms.Label();
            this.labelChampionDefence2 = new System.Windows.Forms.Label();
            this.labelChampionDefence1 = new System.Windows.Forms.Label();
            this.labelDefenceName3 = new System.Windows.Forms.Label();
            this.labelDefenceName2 = new System.Windows.Forms.Label();
            this.labelDefenceName1 = new System.Windows.Forms.Label();
            this.labelChampionDamage3 = new System.Windows.Forms.Label();
            this.labelChampionDamage2 = new System.Windows.Forms.Label();
            this.labelChampionDamage1 = new System.Windows.Forms.Label();
            this.labelDamageName3 = new System.Windows.Forms.Label();
            this.labelDamageName2 = new System.Windows.Forms.Label();
            this.labelDamageName1 = new System.Windows.Forms.Label();
            this.labelChampionDexterity3 = new System.Windows.Forms.Label();
            this.labelChampionDexterity2 = new System.Windows.Forms.Label();
            this.labelChampionDexterity1 = new System.Windows.Forms.Label();
            this.labelDexterityName3 = new System.Windows.Forms.Label();
            this.labelDexterityName2 = new System.Windows.Forms.Label();
            this.labelDexterityName1 = new System.Windows.Forms.Label();
            this.labelChampionInteligence3 = new System.Windows.Forms.Label();
            this.labelChampionInteligence2 = new System.Windows.Forms.Label();
            this.labelChampionInteligence1 = new System.Windows.Forms.Label();
            this.labelInteligenceName3 = new System.Windows.Forms.Label();
            this.labelInteligenceName2 = new System.Windows.Forms.Label();
            this.labelInteligenceName1 = new System.Windows.Forms.Label();
            this.labelChampionTypeAbility3 = new System.Windows.Forms.Label();
            this.labelChampionTypeAbility2 = new System.Windows.Forms.Label();
            this.labelChampionTypeAbility1 = new System.Windows.Forms.Label();
            this.labelTypeAbilityName3 = new System.Windows.Forms.Label();
            this.labelTypeAbilityName2 = new System.Windows.Forms.Label();
            this.labelTypeAbilityName1 = new System.Windows.Forms.Label();
            this.labelChampionClassAbility3 = new System.Windows.Forms.Label();
            this.labelChampionClassAbility2 = new System.Windows.Forms.Label();
            this.labelChampionClassAbility1 = new System.Windows.Forms.Label();
            this.labelClassAbilityName3 = new System.Windows.Forms.Label();
            this.labelClassAbilityName2 = new System.Windows.Forms.Label();
            this.labelClassAbilityName1 = new System.Windows.Forms.Label();
            this.labelTitle = new System.Windows.Forms.Label();
            this.buttonChoose1 = new System.Windows.Forms.Button();
            this.buttonChoose2 = new System.Windows.Forms.Button();
            this.buttonChoose3 = new System.Windows.Forms.Button();
            this.labelChampionAccuracy3 = new System.Windows.Forms.Label();
            this.labelChampionAccuracy2 = new System.Windows.Forms.Label();
            this.labelChampionAccuracy1 = new System.Windows.Forms.Label();
            this.labelAccuracyName3 = new System.Windows.Forms.Label();
            this.labelAccuracyName2 = new System.Windows.Forms.Label();
            this.labelAccuracyName1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelChampionClass1
            // 
            this.labelChampionClass1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelChampionClass1.Location = new System.Drawing.Point(12, 65);
            this.labelChampionClass1.Name = "labelChampionClass1";
            this.labelChampionClass1.Size = new System.Drawing.Size(160, 45);
            this.labelChampionClass1.TabIndex = 0;
            this.labelChampionClass1.Text = "ChampionClass1";
            this.labelChampionClass1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionClass2
            // 
            this.labelChampionClass2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelChampionClass2.Location = new System.Drawing.Point(306, 65);
            this.labelChampionClass2.Name = "labelChampionClass2";
            this.labelChampionClass2.Size = new System.Drawing.Size(160, 45);
            this.labelChampionClass2.TabIndex = 1;
            this.labelChampionClass2.Text = "ChampionClass2";
            this.labelChampionClass2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionClass3
            // 
            this.labelChampionClass3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.labelChampionClass3.Location = new System.Drawing.Point(610, 65);
            this.labelChampionClass3.Name = "labelChampionClass3";
            this.labelChampionClass3.Size = new System.Drawing.Size(160, 45);
            this.labelChampionClass3.TabIndex = 2;
            this.labelChampionClass3.Text = "ChampionClass3";
            this.labelChampionClass3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelHealthName1
            // 
            this.labelHealthName1.Location = new System.Drawing.Point(12, 124);
            this.labelHealthName1.Name = "labelHealthName1";
            this.labelHealthName1.Size = new System.Drawing.Size(75, 30);
            this.labelHealthName1.TabIndex = 3;
            this.labelHealthName1.Text = "Health";
            this.labelHealthName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelHealthName2
            // 
            this.labelHealthName2.Location = new System.Drawing.Point(306, 124);
            this.labelHealthName2.Name = "labelHealthName2";
            this.labelHealthName2.Size = new System.Drawing.Size(75, 30);
            this.labelHealthName2.TabIndex = 4;
            this.labelHealthName2.Text = "Health";
            this.labelHealthName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelHealthName3
            // 
            this.labelHealthName3.Location = new System.Drawing.Point(610, 124);
            this.labelHealthName3.Name = "labelHealthName3";
            this.labelHealthName3.Size = new System.Drawing.Size(75, 30);
            this.labelHealthName3.TabIndex = 5;
            this.labelHealthName3.Text = "Health";
            this.labelHealthName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionHealth1
            // 
            this.labelChampionHealth1.Location = new System.Drawing.Point(97, 124);
            this.labelChampionHealth1.Name = "labelChampionHealth1";
            this.labelChampionHealth1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionHealth1.TabIndex = 6;
            this.labelChampionHealth1.Text = "\"Amount of health\"";
            this.labelChampionHealth1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionHealth2
            // 
            this.labelChampionHealth2.Location = new System.Drawing.Point(391, 124);
            this.labelChampionHealth2.Name = "labelChampionHealth2";
            this.labelChampionHealth2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionHealth2.TabIndex = 7;
            this.labelChampionHealth2.Text = "\"Amount of health\"";
            this.labelChampionHealth2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionHealth3
            // 
            this.labelChampionHealth3.Location = new System.Drawing.Point(695, 124);
            this.labelChampionHealth3.Name = "labelChampionHealth3";
            this.labelChampionHealth3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionHealth3.TabIndex = 8;
            this.labelChampionHealth3.Text = "\"Amount of health\"";
            this.labelChampionHealth3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDefence3
            // 
            this.labelChampionDefence3.Location = new System.Drawing.Point(695, 154);
            this.labelChampionDefence3.Name = "labelChampionDefence3";
            this.labelChampionDefence3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDefence3.TabIndex = 14;
            this.labelChampionDefence3.Text = "\"Amount of defence\"";
            this.labelChampionDefence3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDefence2
            // 
            this.labelChampionDefence2.Location = new System.Drawing.Point(391, 154);
            this.labelChampionDefence2.Name = "labelChampionDefence2";
            this.labelChampionDefence2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDefence2.TabIndex = 13;
            this.labelChampionDefence2.Text = "\"Amount of defence\"";
            this.labelChampionDefence2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDefence1
            // 
            this.labelChampionDefence1.Location = new System.Drawing.Point(97, 154);
            this.labelChampionDefence1.Name = "labelChampionDefence1";
            this.labelChampionDefence1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDefence1.TabIndex = 12;
            this.labelChampionDefence1.Text = "\"Amount of defence\"";
            this.labelChampionDefence1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDefenceName3
            // 
            this.labelDefenceName3.Location = new System.Drawing.Point(610, 154);
            this.labelDefenceName3.Name = "labelDefenceName3";
            this.labelDefenceName3.Size = new System.Drawing.Size(75, 30);
            this.labelDefenceName3.TabIndex = 11;
            this.labelDefenceName3.Text = "Defence";
            this.labelDefenceName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDefenceName2
            // 
            this.labelDefenceName2.Location = new System.Drawing.Point(306, 154);
            this.labelDefenceName2.Name = "labelDefenceName2";
            this.labelDefenceName2.Size = new System.Drawing.Size(75, 30);
            this.labelDefenceName2.TabIndex = 10;
            this.labelDefenceName2.Text = "Defence";
            this.labelDefenceName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDefenceName1
            // 
            this.labelDefenceName1.Location = new System.Drawing.Point(12, 154);
            this.labelDefenceName1.Name = "labelDefenceName1";
            this.labelDefenceName1.Size = new System.Drawing.Size(75, 30);
            this.labelDefenceName1.TabIndex = 9;
            this.labelDefenceName1.Text = "Defence";
            this.labelDefenceName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDamage3
            // 
            this.labelChampionDamage3.Location = new System.Drawing.Point(695, 184);
            this.labelChampionDamage3.Name = "labelChampionDamage3";
            this.labelChampionDamage3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDamage3.TabIndex = 20;
            this.labelChampionDamage3.Text = "\"Amount of damage\"";
            this.labelChampionDamage3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDamage2
            // 
            this.labelChampionDamage2.Location = new System.Drawing.Point(391, 184);
            this.labelChampionDamage2.Name = "labelChampionDamage2";
            this.labelChampionDamage2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDamage2.TabIndex = 19;
            this.labelChampionDamage2.Text = "\"Amount of damage\"";
            this.labelChampionDamage2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDamage1
            // 
            this.labelChampionDamage1.Location = new System.Drawing.Point(97, 184);
            this.labelChampionDamage1.Name = "labelChampionDamage1";
            this.labelChampionDamage1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDamage1.TabIndex = 18;
            this.labelChampionDamage1.Text = "\"Amount of damage\"";
            this.labelChampionDamage1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDamageName3
            // 
            this.labelDamageName3.Location = new System.Drawing.Point(610, 184);
            this.labelDamageName3.Name = "labelDamageName3";
            this.labelDamageName3.Size = new System.Drawing.Size(75, 30);
            this.labelDamageName3.TabIndex = 17;
            this.labelDamageName3.Text = "Damage";
            this.labelDamageName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDamageName2
            // 
            this.labelDamageName2.Location = new System.Drawing.Point(306, 184);
            this.labelDamageName2.Name = "labelDamageName2";
            this.labelDamageName2.Size = new System.Drawing.Size(75, 30);
            this.labelDamageName2.TabIndex = 16;
            this.labelDamageName2.Text = "Damage";
            this.labelDamageName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDamageName1
            // 
            this.labelDamageName1.Location = new System.Drawing.Point(12, 184);
            this.labelDamageName1.Name = "labelDamageName1";
            this.labelDamageName1.Size = new System.Drawing.Size(75, 30);
            this.labelDamageName1.TabIndex = 15;
            this.labelDamageName1.Text = "Damage";
            this.labelDamageName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDexterity3
            // 
            this.labelChampionDexterity3.Location = new System.Drawing.Point(695, 244);
            this.labelChampionDexterity3.Name = "labelChampionDexterity3";
            this.labelChampionDexterity3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDexterity3.TabIndex = 26;
            this.labelChampionDexterity3.Text = "\"Amount of dexterity\"";
            this.labelChampionDexterity3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDexterity2
            // 
            this.labelChampionDexterity2.Location = new System.Drawing.Point(391, 244);
            this.labelChampionDexterity2.Name = "labelChampionDexterity2";
            this.labelChampionDexterity2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDexterity2.TabIndex = 25;
            this.labelChampionDexterity2.Text = "\"Amount of dexterity\"";
            this.labelChampionDexterity2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionDexterity1
            // 
            this.labelChampionDexterity1.Location = new System.Drawing.Point(97, 244);
            this.labelChampionDexterity1.Name = "labelChampionDexterity1";
            this.labelChampionDexterity1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionDexterity1.TabIndex = 24;
            this.labelChampionDexterity1.Text = "\"Amount of dexterity\"";
            this.labelChampionDexterity1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDexterityName3
            // 
            this.labelDexterityName3.Location = new System.Drawing.Point(610, 244);
            this.labelDexterityName3.Name = "labelDexterityName3";
            this.labelDexterityName3.Size = new System.Drawing.Size(75, 30);
            this.labelDexterityName3.TabIndex = 23;
            this.labelDexterityName3.Text = "Dexterity";
            this.labelDexterityName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDexterityName2
            // 
            this.labelDexterityName2.Location = new System.Drawing.Point(306, 244);
            this.labelDexterityName2.Name = "labelDexterityName2";
            this.labelDexterityName2.Size = new System.Drawing.Size(75, 30);
            this.labelDexterityName2.TabIndex = 22;
            this.labelDexterityName2.Text = "Dexterity";
            this.labelDexterityName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDexterityName1
            // 
            this.labelDexterityName1.Location = new System.Drawing.Point(16, 244);
            this.labelDexterityName1.Name = "labelDexterityName1";
            this.labelDexterityName1.Size = new System.Drawing.Size(75, 30);
            this.labelDexterityName1.TabIndex = 21;
            this.labelDexterityName1.Text = "Dexterity";
            this.labelDexterityName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionInteligence3
            // 
            this.labelChampionInteligence3.Location = new System.Drawing.Point(695, 274);
            this.labelChampionInteligence3.Name = "labelChampionInteligence3";
            this.labelChampionInteligence3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionInteligence3.TabIndex = 32;
            this.labelChampionInteligence3.Text = "\"Amount of inteligence\"";
            this.labelChampionInteligence3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionInteligence2
            // 
            this.labelChampionInteligence2.Location = new System.Drawing.Point(391, 274);
            this.labelChampionInteligence2.Name = "labelChampionInteligence2";
            this.labelChampionInteligence2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionInteligence2.TabIndex = 31;
            this.labelChampionInteligence2.Text = "\"Amount of inteligence\"";
            this.labelChampionInteligence2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionInteligence1
            // 
            this.labelChampionInteligence1.Location = new System.Drawing.Point(97, 274);
            this.labelChampionInteligence1.Name = "labelChampionInteligence1";
            this.labelChampionInteligence1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionInteligence1.TabIndex = 30;
            this.labelChampionInteligence1.Text = "\"Amount of inteligence\"";
            this.labelChampionInteligence1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelInteligenceName3
            // 
            this.labelInteligenceName3.Location = new System.Drawing.Point(610, 274);
            this.labelInteligenceName3.Name = "labelInteligenceName3";
            this.labelInteligenceName3.Size = new System.Drawing.Size(75, 30);
            this.labelInteligenceName3.TabIndex = 29;
            this.labelInteligenceName3.Text = "Inteligence";
            this.labelInteligenceName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelInteligenceName2
            // 
            this.labelInteligenceName2.Location = new System.Drawing.Point(306, 274);
            this.labelInteligenceName2.Name = "labelInteligenceName2";
            this.labelInteligenceName2.Size = new System.Drawing.Size(75, 30);
            this.labelInteligenceName2.TabIndex = 28;
            this.labelInteligenceName2.Text = "Inteligence";
            this.labelInteligenceName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelInteligenceName1
            // 
            this.labelInteligenceName1.Location = new System.Drawing.Point(12, 274);
            this.labelInteligenceName1.Name = "labelInteligenceName1";
            this.labelInteligenceName1.Size = new System.Drawing.Size(75, 30);
            this.labelInteligenceName1.TabIndex = 27;
            this.labelInteligenceName1.Text = "Inteligence";
            this.labelInteligenceName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionTypeAbility3
            // 
            this.labelChampionTypeAbility3.Location = new System.Drawing.Point(695, 304);
            this.labelChampionTypeAbility3.Name = "labelChampionTypeAbility3";
            this.labelChampionTypeAbility3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionTypeAbility3.TabIndex = 38;
            this.labelChampionTypeAbility3.Text = "\"Power of type ability\"";
            this.labelChampionTypeAbility3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionTypeAbility2
            // 
            this.labelChampionTypeAbility2.Location = new System.Drawing.Point(391, 304);
            this.labelChampionTypeAbility2.Name = "labelChampionTypeAbility2";
            this.labelChampionTypeAbility2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionTypeAbility2.TabIndex = 37;
            this.labelChampionTypeAbility2.Text = "\"Power of type ability\"";
            this.labelChampionTypeAbility2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionTypeAbility1
            // 
            this.labelChampionTypeAbility1.Location = new System.Drawing.Point(97, 304);
            this.labelChampionTypeAbility1.Name = "labelChampionTypeAbility1";
            this.labelChampionTypeAbility1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionTypeAbility1.TabIndex = 36;
            this.labelChampionTypeAbility1.Text = "\"Power of type ability\"";
            this.labelChampionTypeAbility1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTypeAbilityName3
            // 
            this.labelTypeAbilityName3.Location = new System.Drawing.Point(610, 304);
            this.labelTypeAbilityName3.Name = "labelTypeAbilityName3";
            this.labelTypeAbilityName3.Size = new System.Drawing.Size(75, 30);
            this.labelTypeAbilityName3.TabIndex = 35;
            this.labelTypeAbilityName3.Text = "Type Ability";
            this.labelTypeAbilityName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTypeAbilityName2
            // 
            this.labelTypeAbilityName2.Location = new System.Drawing.Point(306, 304);
            this.labelTypeAbilityName2.Name = "labelTypeAbilityName2";
            this.labelTypeAbilityName2.Size = new System.Drawing.Size(75, 30);
            this.labelTypeAbilityName2.TabIndex = 34;
            this.labelTypeAbilityName2.Text = "Type Ability";
            this.labelTypeAbilityName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTypeAbilityName1
            // 
            this.labelTypeAbilityName1.Location = new System.Drawing.Point(12, 304);
            this.labelTypeAbilityName1.Name = "labelTypeAbilityName1";
            this.labelTypeAbilityName1.Size = new System.Drawing.Size(75, 30);
            this.labelTypeAbilityName1.TabIndex = 33;
            this.labelTypeAbilityName1.Text = "Type Ability";
            this.labelTypeAbilityName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionClassAbility3
            // 
            this.labelChampionClassAbility3.Location = new System.Drawing.Point(695, 334);
            this.labelChampionClassAbility3.Name = "labelChampionClassAbility3";
            this.labelChampionClassAbility3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionClassAbility3.TabIndex = 44;
            this.labelChampionClassAbility3.Text = "\"Power of class ability\"";
            this.labelChampionClassAbility3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionClassAbility2
            // 
            this.labelChampionClassAbility2.Location = new System.Drawing.Point(391, 334);
            this.labelChampionClassAbility2.Name = "labelChampionClassAbility2";
            this.labelChampionClassAbility2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionClassAbility2.TabIndex = 43;
            this.labelChampionClassAbility2.Text = "\"Power of class ability\"";
            this.labelChampionClassAbility2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionClassAbility1
            // 
            this.labelChampionClassAbility1.Location = new System.Drawing.Point(97, 334);
            this.labelChampionClassAbility1.Name = "labelChampionClassAbility1";
            this.labelChampionClassAbility1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionClassAbility1.TabIndex = 42;
            this.labelChampionClassAbility1.Text = "\"Power of class ability\"";
            this.labelChampionClassAbility1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelClassAbilityName3
            // 
            this.labelClassAbilityName3.Location = new System.Drawing.Point(610, 334);
            this.labelClassAbilityName3.Name = "labelClassAbilityName3";
            this.labelClassAbilityName3.Size = new System.Drawing.Size(75, 30);
            this.labelClassAbilityName3.TabIndex = 41;
            this.labelClassAbilityName3.Text = "Class Ability";
            this.labelClassAbilityName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelClassAbilityName2
            // 
            this.labelClassAbilityName2.Location = new System.Drawing.Point(306, 334);
            this.labelClassAbilityName2.Name = "labelClassAbilityName2";
            this.labelClassAbilityName2.Size = new System.Drawing.Size(75, 30);
            this.labelClassAbilityName2.TabIndex = 40;
            this.labelClassAbilityName2.Text = "Class Ability";
            this.labelClassAbilityName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelClassAbilityName1
            // 
            this.labelClassAbilityName1.Location = new System.Drawing.Point(12, 334);
            this.labelClassAbilityName1.Name = "labelClassAbilityName1";
            this.labelClassAbilityName1.Size = new System.Drawing.Size(75, 30);
            this.labelClassAbilityName1.TabIndex = 39;
            this.labelClassAbilityName1.Text = "Class Ability";
            this.labelClassAbilityName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTitle
            // 
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTitle.Location = new System.Drawing.Point(266, 9);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(240, 45);
            this.labelTitle.TabIndex = 45;
            this.labelTitle.Text = "Choose One Champion";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonChoose1
            // 
            this.buttonChoose1.Location = new System.Drawing.Point(16, 388);
            this.buttonChoose1.Name = "buttonChoose1";
            this.buttonChoose1.Size = new System.Drawing.Size(156, 55);
            this.buttonChoose1.TabIndex = 46;
            this.buttonChoose1.Text = "Choose <class>";
            this.buttonChoose1.UseVisualStyleBackColor = true;
            this.buttonChoose1.Click += new System.EventHandler(this.buttonChoose1_Click);
            // 
            // buttonChoose2
            // 
            this.buttonChoose2.Location = new System.Drawing.Point(310, 388);
            this.buttonChoose2.Name = "buttonChoose2";
            this.buttonChoose2.Size = new System.Drawing.Size(156, 55);
            this.buttonChoose2.TabIndex = 47;
            this.buttonChoose2.Text = "Choose <class>";
            this.buttonChoose2.UseVisualStyleBackColor = true;
            this.buttonChoose2.Click += new System.EventHandler(this.buttonChoose2_Click);
            // 
            // buttonChoose3
            // 
            this.buttonChoose3.Location = new System.Drawing.Point(614, 388);
            this.buttonChoose3.Name = "buttonChoose3";
            this.buttonChoose3.Size = new System.Drawing.Size(156, 55);
            this.buttonChoose3.TabIndex = 48;
            this.buttonChoose3.Text = "Choose <class>";
            this.buttonChoose3.UseVisualStyleBackColor = true;
            this.buttonChoose3.Click += new System.EventHandler(this.buttonChoose3_Click);
            // 
            // labelChampionAccuracy3
            // 
            this.labelChampionAccuracy3.Location = new System.Drawing.Point(695, 214);
            this.labelChampionAccuracy3.Name = "labelChampionAccuracy3";
            this.labelChampionAccuracy3.Size = new System.Drawing.Size(75, 30);
            this.labelChampionAccuracy3.TabIndex = 54;
            this.labelChampionAccuracy3.Text = "\"Amount of accuracy\"";
            this.labelChampionAccuracy3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionAccuracy2
            // 
            this.labelChampionAccuracy2.Location = new System.Drawing.Point(391, 214);
            this.labelChampionAccuracy2.Name = "labelChampionAccuracy2";
            this.labelChampionAccuracy2.Size = new System.Drawing.Size(75, 30);
            this.labelChampionAccuracy2.TabIndex = 53;
            this.labelChampionAccuracy2.Text = "\"Amount of accuracy\"";
            this.labelChampionAccuracy2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelChampionAccuracy1
            // 
            this.labelChampionAccuracy1.Location = new System.Drawing.Point(97, 214);
            this.labelChampionAccuracy1.Name = "labelChampionAccuracy1";
            this.labelChampionAccuracy1.Size = new System.Drawing.Size(75, 30);
            this.labelChampionAccuracy1.TabIndex = 52;
            this.labelChampionAccuracy1.Text = "\"Amount of accuracy\"";
            this.labelChampionAccuracy1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelAccuracyName3
            // 
            this.labelAccuracyName3.Location = new System.Drawing.Point(610, 214);
            this.labelAccuracyName3.Name = "labelAccuracyName3";
            this.labelAccuracyName3.Size = new System.Drawing.Size(75, 30);
            this.labelAccuracyName3.TabIndex = 51;
            this.labelAccuracyName3.Text = "Accuracy";
            this.labelAccuracyName3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelAccuracyName2
            // 
            this.labelAccuracyName2.Location = new System.Drawing.Point(306, 214);
            this.labelAccuracyName2.Name = "labelAccuracyName2";
            this.labelAccuracyName2.Size = new System.Drawing.Size(75, 30);
            this.labelAccuracyName2.TabIndex = 50;
            this.labelAccuracyName2.Text = "Accuracy";
            this.labelAccuracyName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelAccuracyName1
            // 
            this.labelAccuracyName1.Location = new System.Drawing.Point(12, 214);
            this.labelAccuracyName1.Name = "labelAccuracyName1";
            this.labelAccuracyName1.Size = new System.Drawing.Size(75, 30);
            this.labelAccuracyName1.TabIndex = 49;
            this.labelAccuracyName1.Text = "Accuracy";
            this.labelAccuracyName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormNewChampions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 466);
            this.Controls.Add(this.labelChampionAccuracy3);
            this.Controls.Add(this.labelChampionAccuracy2);
            this.Controls.Add(this.labelChampionAccuracy1);
            this.Controls.Add(this.labelAccuracyName3);
            this.Controls.Add(this.labelAccuracyName2);
            this.Controls.Add(this.labelAccuracyName1);
            this.Controls.Add(this.buttonChoose3);
            this.Controls.Add(this.buttonChoose2);
            this.Controls.Add(this.buttonChoose1);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.labelChampionClassAbility3);
            this.Controls.Add(this.labelChampionClassAbility2);
            this.Controls.Add(this.labelChampionClassAbility1);
            this.Controls.Add(this.labelClassAbilityName3);
            this.Controls.Add(this.labelClassAbilityName2);
            this.Controls.Add(this.labelClassAbilityName1);
            this.Controls.Add(this.labelChampionTypeAbility3);
            this.Controls.Add(this.labelChampionTypeAbility2);
            this.Controls.Add(this.labelChampionTypeAbility1);
            this.Controls.Add(this.labelTypeAbilityName3);
            this.Controls.Add(this.labelTypeAbilityName2);
            this.Controls.Add(this.labelTypeAbilityName1);
            this.Controls.Add(this.labelChampionInteligence3);
            this.Controls.Add(this.labelChampionInteligence2);
            this.Controls.Add(this.labelChampionInteligence1);
            this.Controls.Add(this.labelInteligenceName3);
            this.Controls.Add(this.labelInteligenceName2);
            this.Controls.Add(this.labelInteligenceName1);
            this.Controls.Add(this.labelChampionDexterity3);
            this.Controls.Add(this.labelChampionDexterity2);
            this.Controls.Add(this.labelChampionDexterity1);
            this.Controls.Add(this.labelDexterityName3);
            this.Controls.Add(this.labelDexterityName2);
            this.Controls.Add(this.labelDexterityName1);
            this.Controls.Add(this.labelChampionDamage3);
            this.Controls.Add(this.labelChampionDamage2);
            this.Controls.Add(this.labelChampionDamage1);
            this.Controls.Add(this.labelDamageName3);
            this.Controls.Add(this.labelDamageName2);
            this.Controls.Add(this.labelDamageName1);
            this.Controls.Add(this.labelChampionDefence3);
            this.Controls.Add(this.labelChampionDefence2);
            this.Controls.Add(this.labelChampionDefence1);
            this.Controls.Add(this.labelDefenceName3);
            this.Controls.Add(this.labelDefenceName2);
            this.Controls.Add(this.labelDefenceName1);
            this.Controls.Add(this.labelChampionHealth3);
            this.Controls.Add(this.labelChampionHealth2);
            this.Controls.Add(this.labelChampionHealth1);
            this.Controls.Add(this.labelHealthName3);
            this.Controls.Add(this.labelHealthName2);
            this.Controls.Add(this.labelHealthName1);
            this.Controls.Add(this.labelChampionClass3);
            this.Controls.Add(this.labelChampionClass2);
            this.Controls.Add(this.labelChampionClass1);
            this.Name = "FormNewChampions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormNewChampions";
            this.Load += new System.EventHandler(this.FormNewChampions_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelChampionClass1;
        private System.Windows.Forms.Label labelChampionClass2;
        private System.Windows.Forms.Label labelChampionClass3;
        private System.Windows.Forms.Label labelHealthName1;
        private System.Windows.Forms.Label labelHealthName2;
        private System.Windows.Forms.Label labelHealthName3;
        private System.Windows.Forms.Label labelChampionHealth1;
        private System.Windows.Forms.Label labelChampionHealth2;
        private System.Windows.Forms.Label labelChampionHealth3;
        private System.Windows.Forms.Label labelChampionDefence3;
        private System.Windows.Forms.Label labelChampionDefence2;
        private System.Windows.Forms.Label labelChampionDefence1;
        private System.Windows.Forms.Label labelDefenceName3;
        private System.Windows.Forms.Label labelDefenceName2;
        private System.Windows.Forms.Label labelDefenceName1;
        private System.Windows.Forms.Label labelChampionDamage3;
        private System.Windows.Forms.Label labelChampionDamage2;
        private System.Windows.Forms.Label labelChampionDamage1;
        private System.Windows.Forms.Label labelDamageName3;
        private System.Windows.Forms.Label labelDamageName2;
        private System.Windows.Forms.Label labelDamageName1;
        private System.Windows.Forms.Label labelChampionDexterity3;
        private System.Windows.Forms.Label labelChampionDexterity2;
        private System.Windows.Forms.Label labelChampionDexterity1;
        private System.Windows.Forms.Label labelDexterityName3;
        private System.Windows.Forms.Label labelDexterityName2;
        private System.Windows.Forms.Label labelDexterityName1;
        private System.Windows.Forms.Label labelChampionInteligence3;
        private System.Windows.Forms.Label labelChampionInteligence2;
        private System.Windows.Forms.Label labelChampionInteligence1;
        private System.Windows.Forms.Label labelInteligenceName3;
        private System.Windows.Forms.Label labelInteligenceName2;
        private System.Windows.Forms.Label labelInteligenceName1;
        private System.Windows.Forms.Label labelChampionTypeAbility3;
        private System.Windows.Forms.Label labelChampionTypeAbility2;
        private System.Windows.Forms.Label labelChampionTypeAbility1;
        private System.Windows.Forms.Label labelTypeAbilityName3;
        private System.Windows.Forms.Label labelTypeAbilityName2;
        private System.Windows.Forms.Label labelTypeAbilityName1;
        private System.Windows.Forms.Label labelChampionClassAbility3;
        private System.Windows.Forms.Label labelChampionClassAbility2;
        private System.Windows.Forms.Label labelChampionClassAbility1;
        private System.Windows.Forms.Label labelClassAbilityName3;
        private System.Windows.Forms.Label labelClassAbilityName2;
        private System.Windows.Forms.Label labelClassAbilityName1;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button buttonChoose1;
        private System.Windows.Forms.Button buttonChoose2;
        private System.Windows.Forms.Button buttonChoose3;
        private System.Windows.Forms.Label labelChampionAccuracy3;
        private System.Windows.Forms.Label labelChampionAccuracy2;
        private System.Windows.Forms.Label labelChampionAccuracy1;
        private System.Windows.Forms.Label labelAccuracyName3;
        private System.Windows.Forms.Label labelAccuracyName2;
        private System.Windows.Forms.Label labelAccuracyName1;
    }
}