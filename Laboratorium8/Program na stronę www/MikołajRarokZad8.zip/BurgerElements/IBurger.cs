﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MikołajRarokZad8.BurgerElements
{
    /// <summary>
    /// Interfejs burgera
    /// </summary>
    public interface IBurger
    {
        string GetBurgerType();
    }
}
