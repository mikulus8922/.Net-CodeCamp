﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MikołajRarokZad4.ViewModels
{
    /// <summary>
    /// Model pokoi
    /// </summary>
    public class RoomViewModel
    {
        public int Id { get; set; }
        public int Number { get; set; }
        public int RoomCapacity { get; set; }
        public int Floor { get; set; }

    }
}
