﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MikołajRarokZad6.Models
{

    /// <summary>
    /// ViewModel danych użytkownika
    /// </summary>
    public class UserGreetingsViewModel
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}
